#!/bin/sh

cd /home/user
./challenge